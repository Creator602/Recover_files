@echo off
echo Loading...
timeout /t 2 >nul
start https://www.youtube.com/watch?v=dQw4w9WgXcQ
exit